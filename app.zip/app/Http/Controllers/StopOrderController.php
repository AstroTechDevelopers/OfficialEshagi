<?php

namespace App\Http\Controllers;

use App\Models\StopOrder;
use Illuminate\Http\Request;

class StopOrderController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\StopOrder  $stopOrder
     * @return \Illuminate\Http\Response
     */
    public function show(StopOrder $stopOrder)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\StopOrder  $stopOrder
     * @return \Illuminate\Http\Response
     */
    public function edit(StopOrder $stopOrder)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\StopOrder  $stopOrder
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, StopOrder $stopOrder)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\StopOrder  $stopOrder
     * @return \Illuminate\Http\Response
     */
    public function destroy(StopOrder $stopOrder)
    {
        //
    }
}
