<?php

namespace App\Http\Controllers;

use App\Models\MerchantKyc;
use Illuminate\Http\Request;

class MerchantKycController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\MerchantKyc  $merchantKyc
     * @return \Illuminate\Http\Response
     */
    public function show(MerchantKyc $merchantKyc)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\MerchantKyc  $merchantKyc
     * @return \Illuminate\Http\Response
     */
    public function edit(MerchantKyc $merchantKyc)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\MerchantKyc  $merchantKyc
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, MerchantKyc $merchantKyc)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\MerchantKyc  $merchantKyc
     * @return \Illuminate\Http\Response
     */
    public function destroy(MerchantKyc $merchantKyc)
    {
        //
    }
}
