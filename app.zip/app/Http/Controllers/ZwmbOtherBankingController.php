<?php

namespace App\Http\Controllers;

use App\Models\ZwmbOtherBanking;
use Illuminate\Http\Request;

class ZwmbOtherBankingController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\ZwmbOtherBanking  $zwmbOtherBanking
     * @return \Illuminate\Http\Response
     */
    public function show(ZwmbOtherBanking $zwmbOtherBanking)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\ZwmbOtherBanking  $zwmbOtherBanking
     * @return \Illuminate\Http\Response
     */
    public function edit(ZwmbOtherBanking $zwmbOtherBanking)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\ZwmbOtherBanking  $zwmbOtherBanking
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ZwmbOtherBanking $zwmbOtherBanking)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\ZwmbOtherBanking  $zwmbOtherBanking
     * @return \Illuminate\Http\Response
     */
    public function destroy(ZwmbOtherBanking $zwmbOtherBanking)
    {
        //
    }
}
