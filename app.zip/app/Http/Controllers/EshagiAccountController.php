<?php

namespace App\Http\Controllers;

use App\Models\EshagiAccount;
use Illuminate\Http\Request;

class EshagiAccountController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\EshagiAccount  $eshagiAccount
     * @return \Illuminate\Http\Response
     */
    public function show(EshagiAccount $eshagiAccount)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\EshagiAccount  $eshagiAccount
     * @return \Illuminate\Http\Response
     */
    public function edit(EshagiAccount $eshagiAccount)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\EshagiAccount  $eshagiAccount
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, EshagiAccount $eshagiAccount)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\EshagiAccount  $eshagiAccount
     * @return \Illuminate\Http\Response
     */
    public function destroy(EshagiAccount $eshagiAccount)
    {
        //
    }
}
