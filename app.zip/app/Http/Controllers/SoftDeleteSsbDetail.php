<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class SoftDeleteSsbDetail extends Controller
{
    //
}
