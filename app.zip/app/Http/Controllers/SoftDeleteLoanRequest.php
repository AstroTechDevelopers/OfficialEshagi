<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class SoftDeleteLoanRequest extends Controller
{
    //
}
