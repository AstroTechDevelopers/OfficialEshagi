@component('mail::message')
Good day All,

Please find attached the loans weekly status report as at 16:10.

Thanks,<br>
{{ config('app.name') }}
@endcomponent
