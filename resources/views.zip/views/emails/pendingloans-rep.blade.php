@component('mail::message')
Good day All,

Please find attached the pending loans report as at 16:00.

Thanks,<br>
{{ config('app.name') }}
@endcomponent
