@component('mail::message')
Good day All,

Please find attached the executive summary as of 1655 Hrs.

Thanks,<br>
{{ config('app.name') }}
@endcomponent
