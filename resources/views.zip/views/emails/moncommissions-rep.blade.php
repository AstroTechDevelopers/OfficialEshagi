@component('mail::message')
Good day All,

Please find attached the monthly commissions due report as at 07:00.

Thanks,<br>
{{ config('app.name') }}
@endcomponent
