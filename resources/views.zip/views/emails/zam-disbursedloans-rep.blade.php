@component('mail::message')
Good day All,

Please find attached the Zambia disbursed loans report as at 16:30.

Thanks,<br>
{{ config('app.name') }}
@endcomponent
