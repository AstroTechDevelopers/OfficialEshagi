@component('mail::message')
Good day All,

Please find attached the sales admin - loans report as at 17:00.

Thanks,<br>
{{ config('app.name') }}
@endcomponent
