@component('mail::message')
Good day All,

Please find attached the daily merchant loans report as at 16:30.

Thanks,<br>
{{ config('app.name') }}
@endcomponent
